import streamlit as st
import subprocess
import snowflake.connector
import pandas as pd

# Snowflake connection details (update with your credentials)
SNOWFLAKE_CONFIG = {
    "user": "NAMAN1310",
    "password": "Guru1310@",
    "account": "LZYUQGQ-NRB19233",
    "warehouse": "COMPUTE_WH",
    "database": "DBTPOC",
    "schema": "CUSTOMER_DATA_CLEANING"
}

def run_dbt_command(command):
    if command == "dbt run":
        result = subprocess.run(
            "dbt run --models null_check capitalization datatypes dup formatting outliers",
            shell=True, capture_output=True, text=True
        )
    else:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout, result.stderr

# Function to fetch table names from Snowflake
def get_snowflake_tables():
    try:
        conn = snowflake.connector.connect(**SNOWFLAKE_CONFIG)
        query = """
        SELECT TABLE_NAME 
        FROM INFORMATION_SCHEMA.TABLES 
        WHERE TABLE_NAME IN ('NULL_CHECK', 'CAPITALIZATION', 'DATATYPES', 'DUP', 'FORMATTING', 'OUTLIERS')
        """
        df = pd.read_sql(query, conn)
        conn.close()
        return df["TABLE_NAME"].tolist()
    except Exception as e:
        return str(e)

# Function to fetch full table contents
def get_table_data(table_name):
    try:
        conn = snowflake.connector.connect(**SNOWFLAKE_CONFIG)
        query = f"SELECT * FROM {table_name}"
        df = pd.read_sql(query, conn)
        conn.close()
        return df
    except Exception as e:
        return str(e)

# Streamlit UI
st.title("Run dbt and Connect to Snowflake")

# Select dbt command
command_option = st.selectbox(
    "Choose a dbt command to run:",
    ["dbt run", "dbt test", "dbt debug", "dbt seed", "dbt snapshot"]
)

# Run dbt command
if st.button("Execute dbt Command"):
    st.write(f"Running: {command_option}")
    output, error = run_dbt_command(command_option)
    
    if error:
        st.error(f"Error: {error}")
    else:
        st.success("dbt Command Executed Successfully!")
        st.text_area("Output", output, height=300)

# Fetch and display table names
tables = get_snowflake_tables()
if isinstance(tables, str):
    st.error(f"Error fetching tables: {tables}")
else:
    selected_table = st.selectbox("Select a table to view data:", tables)

    # Fetch and display full table data
    if st.button(f"Show Data for {selected_table}"):
        table_data = get_table_data(selected_table)
        if isinstance(table_data, str):
            st.error(f"Error fetching data: {table_data}")
        else:
            st.success(f"Displaying data for {selected_table}")
            st.dataframe(table_data)
