{{ config(
    materialized='table',
    schema='DATA_CLEANING',
) }}

SELECT 
    PRODUCT_A.PRODUCT_ID AS product_a_id,
    PRODUCT_B.PRODUCT_ID AS product_b_id
FROM PRODUCT_A
JOIN PRODUCT_B 
ON 
    (PRODUCT_A.name = PRODUCT_B.name AND PRODUCT_A.model_number = PRODUCT_B.model_number AND PRODUCT_A.weight = PRODUCT_B.weight AND PRODUCT_A.color = PRODUCT_B.color AND PRODUCT_A.material = PRODUCT_B.material)
    OR 
    (PRODUCT_A.serial_number = PRODUCT_B.serial_number)
WHERE 
    PRODUCT_A.PRODUCT_ID IS NOT NULL 
    AND PRODUCT_B.PRODUCT_ID IS NOT NULL
