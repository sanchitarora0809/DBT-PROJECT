{{ config(
    materialized='table',
    schema='DATA_CLEANING'
) }}

{% set res = [
    ('CUSTOMERS', 'FIRST_NAME', '  John  '),
    ('CUSTOMERS', 'LAST_NAME', '  White  '),
    ('ORDERS', 'ORDER_DATE', '  2023-10-01  ')
] %}

WITH results_list AS (
    SELECT
        table_name,
        column_name,
        'TRIM' AS ERROR,
        error_data
    FROM (VALUES 
        {% for row in res %}
            ('{{ row[0] }}', '{{ row[1] }}', '{{ row[2] }}', '{{ row[3] }}'){% if not loop.last %},{% endif %}
        {% endfor %}
    ) AS results_list (table_name, column_name, error_data)
),

cleaned_data AS (
    SELECT
        table_name,
        column_name,
        'TRIM' AS ERROR,
        error_data AS cleaned_data
    FROM results_list
)

SELECT
    table_name,
    column_name,
    'TRIM' AS ERROR,
    OBJECT_CONSTRUCT(
        'table_name', table_name,
        'column_name', column_name,
        'cleaned_data', cleaned_data
    ) AS cleaned_row_json
FROM cleaned_data