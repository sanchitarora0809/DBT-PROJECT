{{ config(
    materialized='table',
    schema='DATA_CLEANING',
)}}

SELECT 
    customer_abc.id AS customer_abc_id,
    customer_xyz.id AS customer_xyz_id
FROM customer_abc
JOIN customer_xyz 
ON 
    (customer_abc.last_name = customer_xyz.last_name AND customer_abc.phone_number = customer_xyz.phone_number)
    OR 
    (customer_abc.full_name = customer_xyz.full_name AND customer_abc.address = customer_xyz.address)
WHERE 
    customer_abc.id IS NOT NULL 
    AND customer_xyz.id IS NOT NULL
