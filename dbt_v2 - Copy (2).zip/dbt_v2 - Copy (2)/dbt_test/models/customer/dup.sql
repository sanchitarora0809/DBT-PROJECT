{{ config(
    materialized='table',
    schema='DATA_CLEANING'
) }}


{% set res = see() %}

SELECT
    *
FROM (VALUES 
    {% for row in res %}
        ('{{ row[0] }}', '{{ row[1] }}', '{{ row[2] }}'){% if not loop.last %},{% endif %}
        {{log("heloooooooooo"~res)}}
    {% endfor %}
) AS results_list (table_name, column_name, error_data)
{% if not results_list_exe %}
    UNION ALL
    SELECT NULL AS table_name, NULL AS column_name, NULL AS error_data
    WHERE 1=0
{% endif %}