{{ config(
    materialized='table',
    schema='DATA_CLEANING',
) }}

SELECT 
    COALESCE(customer_abc.id, customer_xyz.id) AS customer_id,
    COALESCE(
        CASE 
            WHEN LENGTH(customer_abc.full_name) > LENGTH(customer_xyz.full_name) THEN customer_abc.full_name
            ELSE customer_xyz.full_name
        END, 
        customer_abc.full_name, customer_xyz.full_name
    ) AS full_name,
    COALESCE(customer_abc.last_name, customer_xyz.last_name) AS last_name,
    COALESCE(customer_abc.phone_number, customer_xyz.phone_number) AS phone_number,
    COALESCE(
        CASE 
            WHEN customer_abc.email IS NOT NULL AND customer_xyz.email IS NOT NULL AND customer_abc.email != customer_xyz.email 
            THEN customer_abc.email || ' / ' || customer_xyz.email
            ELSE COALESCE(customer_abc.email, customer_xyz.email)
        END, 
        ''
    ) AS email,
    COALESCE(customer_abc.date_of_birth, customer_xyz.date_of_birth) AS date_of_birth,
    COALESCE(customer_abc.address, customer_xyz.address) AS address,
    COALESCE(customer_abc.city, customer_xyz.city) AS city,
    COALESCE(customer_abc.state, customer_xyz.state) AS state,
    COALESCE(customer_abc.zip_code, customer_xyz.zip_code) AS zip_code,
    COALESCE(customer_abc.country, customer_xyz.country) AS country,
    CASE 
        WHEN customer_abc.id IS NOT NULL AND customer_xyz.id IS NOT NULL THEN 1  
        ELSE 0 
    END AS flag
FROM customer_abc
FULL JOIN customer_xyz 
ON 
    (customer_abc.last_name = customer_xyz.last_name AND customer_abc.phone_number = customer_xyz.phone_number)
    OR 
    (customer_abc.full_name = customer_xyz.full_name AND customer_abc.address = customer_xyz.address)