{{ config(
    materialized='table',
    schema='DATA_CLEANING',
) }}

SELECT 
    COALESCE(PRODUCT_A.PRODUCT_ID, PRODUCT_B.PRODUCT_ID) AS product_id,
    COALESCE(
        CASE 
            WHEN LENGTH(PRODUCT_A.name) > LENGTH(PRODUCT_B.name) THEN PRODUCT_A.name
            ELSE PRODUCT_B.name
        END, 
        PRODUCT_A.name, PRODUCT_B.name
    ) AS product_name,
    COALESCE(PRODUCT_A.model_number, PRODUCT_B.model_number) AS model_number,
    COALESCE(PRODUCT_A.serial_number, PRODUCT_B.serial_number) AS serial_number,
    COALESCE(PRODUCT_A.sku, PRODUCT_B.sku) AS sku,
    COALESCE(PRODUCT_A.barcode, PRODUCT_B.barcode) AS barcode,
    COALESCE(PRODUCT_A.category_id, PRODUCT_B.category_id) AS category_id,
    COALESCE(PRODUCT_A.brand_id, PRODUCT_B.brand_id) AS brand_id,
    COALESCE(
        CASE 
            WHEN PRODUCT_A.description IS NOT NULL AND PRODUCT_B.description IS NOT NULL 
                 AND PRODUCT_A.description != PRODUCT_B.description 
            THEN PRODUCT_A.description || ' / ' || PRODUCT_B.description
            ELSE COALESCE(PRODUCT_A.description, PRODUCT_B.description)
        END, 
        ''
    ) AS description,
    COALESCE(PRODUCT_A.price, PRODUCT_B.price) AS price,
    COALESCE(PRODUCT_A.discount, PRODUCT_B.discount) AS discount,
    COALESCE(PRODUCT_A.stock_quantity, PRODUCT_B.stock_quantity) AS stock_quantity,
    COALESCE(PRODUCT_A.weight, PRODUCT_B.weight) AS weight,
    COALESCE(PRODUCT_A.color, PRODUCT_B.color) AS color,
    COALESCE(PRODUCT_A.material, PRODUCT_B.material) AS material,
    COALESCE(PRODUCT_A.manufacture_date, PRODUCT_B.manufacture_date) AS manufacture_date,
    COALESCE(PRODUCT_A.supplier_id, PRODUCT_B.supplier_id) AS supplier_id,
    CASE 
        WHEN PRODUCT_A.PRODUCT_ID IS NOT NULL AND PRODUCT_B.PRODUCT_ID IS NOT NULL THEN 1  -- Duplicate Record
        ELSE 0  -- Unique Record
    END AS flag
FROM PRODUCT_A
FULL JOIN PRODUCT_B 
ON 
    (PRODUCT_A.name = PRODUCT_B.name AND PRODUCT_A.model_number = PRODUCT_B.model_number AND PRODUCT_A.weight = PRODUCT_B.weight AND PRODUCT_A.color = PRODUCT_B.color AND PRODUCT_A.material = PRODUCT_B.material)
    OR 
    (PRODUCT_A.serial_number = PRODUCT_B.serial_number)