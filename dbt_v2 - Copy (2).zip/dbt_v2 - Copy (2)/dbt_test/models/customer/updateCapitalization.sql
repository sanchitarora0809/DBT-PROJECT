{{ config(
    materialized='table',
    schema='DATA_CLEANING',
) }}


{% set cet = create_table_if_not_exists() %}



SELECT * FROM {{ref('capitalization')}}