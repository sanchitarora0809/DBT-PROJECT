{% set res = dynamic_full_outer_join('CUSTOMER_ABC', 'CUSTOMER_XYZ') %}

select * from res