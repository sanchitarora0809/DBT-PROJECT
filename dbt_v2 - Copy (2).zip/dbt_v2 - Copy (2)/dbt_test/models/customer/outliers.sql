{{ config(
    materialized='table',
    schema='DATA_CLEANING',
) }}


{% set query %}
SELECT LISTAGG(
    'SELECT ''' || table_name || ''' AS TABLE_NAME, ''' || column_name || ''' AS COLUMN_NAME, ' || 
    ' ''standardized value > 3'' AS ERROR,OBJECT_CONSTRUCT(*) FROM ' || table_name || 
    ' WHERE ABS((' || column_name || ' - (SELECT AVG(' || column_name || ') FROM ' || table_name || ')) / ' || 
    '(SELECT STDDEV(' || column_name || ') FROM ' || table_name || ')) > 3',
    ' UNION\t\n'
) AS dynamic_sql
FROM information_schema.columns
WHERE table_name IN (
    SELECT table_name 
    FROM INFORMATION_SCHEMA.tables 
    WHERE table_type = 'BASE TABLE' 
    AND table_schema = 'CUSTOMER'
)
AND data_type = 'NUMBER'
{% endset %}

{% set results_list_exe = check_null_values(query) %}

SELECT
    *
FROM (VALUES 
    {% for row in results_list_exe %}
        ('{{ row[0] }}','{{row[1]}}','{{row[2]}}','{{row[3]}}') {% if not loop.last %},{% endif %}
    {% endfor %}
) AS results_list (table_name,column_name,error_data)

{% if not results_list_exe %}
    UNION ALL
    SELECT NULL AS table_name, NULL AS column_name, NULL AS error_data
    WHERE 1=0
{% endif %}