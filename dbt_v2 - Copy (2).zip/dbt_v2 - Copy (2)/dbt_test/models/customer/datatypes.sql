{{ config(
    materialized='table',
    schema='DATA_CLEANING'
) }}

{% set res = [
    ('CUSTOMERS', 'PHONE', '123-456-7890'),
    ('ORDERS', 'ORDER_DATE', '2023-10-01'),
    ('ORDERS', 'ORDER_DATE', '2023-10-02')
] %}

WITH results_list AS (
    SELECT
        table_name,
        column_name,
        error_data
    FROM (VALUES 
        {% for row in res %}
            ('{{ row[0] }}', '{{ row[1] }}', '{{ row[2] }}'){% if not loop.last %},{% endif %}
        {% endfor %}
    ) AS results_list (table_name, column_name, error_data)
)

SELECT
    table_name,
    column_name,
    OBJECT_CONSTRUCT(
        'table_name', table_name,
        'column_name', column_name,
        'error_data', error_data
    ) AS error_row_json
FROM results_list