{{ config(
    materialized='table',
    schema='DATA_CLEANING',
) }}


SELECT
    MIN(customer_id) AS id,
    MAX(COALESCE(first_name,'')) AS first_name,
    COALESCE(last_name,'') AS last_name,
    MAX(COALESCE(email, '')) AS email, 
    COALESCE(phone, '') AS phone, 
    MIN(city) AS city,
    MIN(country) AS country
FROM (
    SELECT * FROM customers
    UNION ALL
    SELECT * FROM customer_2
) AS combined_customers
GROUP BY
    COALESCE(last_name, ''),
    COALESCE(phone, '')