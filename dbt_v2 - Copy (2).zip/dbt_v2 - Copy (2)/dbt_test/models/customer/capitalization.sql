{{ config(
    materialized='table',
    schema='DATA_CLEANING',
) }}

{% set query %}
select 
LISTAGG(CONCAT(
'SELECT ''', table_name, ''' AS TABLE_NAME, ''', column_name, ''' AS COLUMN_NAME, ''PascalCase'' AS ERROR ,object_construct(*)' ,'  FROM ', table_name, ' WHERE ', column_name, ' <> INITCAP(', column_name ,')'), ' UNION\t\n'
 )
from information_schema.columns
where table_name IN
(SELECT table_name 
         FROM INFORMATION_SCHEMA.tables 
         WHERE table_type = 'BASE TABLE' 
         AND table_schema = 'CUSTOMER')
AND data_type = 'TEXT'
AND LOWER(COLUMN_NAME) <> 'email'
{% endset %}

{% set results_list_exe = check_null_values(query) %}

SELECT
    *
FROM (VALUES 
    {% for row in results_list_exe %}
        ('{{ row[0] }}','{{row[1]}}','{{row[2]}}', '{{ row[3] }}') {% if not loop.last %},{% endif %}
    {% endfor %}
) AS results_list (table_name,column_name,error,error_data)

{% if not results_list_exe %}
    UNION ALL
    SELECT NULL AS table_name, NULL AS column_name, NULL AS error_data
    WHERE 1=0
{% endif %}