{% macro get_column_names(table_name) %}
    WITH column_info AS (
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_NAME = UPPER('{{ table_name }}')
    )
    SELECT LISTAGG(COLUMN_NAME, ', ') AS column_list FROM column_info;
{% endmacro %}