{{ config(
    materialized='table',
    schema='DATA_CLEANING'
) }}

{% set query %}
show primary keys in customers;
{% endset %}

{% set result = run_query(query) %}

{% set query_2 %}
select "column_name" from table(result_scan(last_query_id()));
{% endset %}

{% set result_2 = run_query(query_2) %}

{% if execute %}
    {% set results_list_exe = result_2.rows[0] %}
{% else %}
    {% set results_list_exe = [] %}
{% endif %}


{% set query_3 %}
SELECT LISTAGG(
    CONCAT(
        'SELECT ''', table_name, ''' AS TABLE_NAME, ''', column_name, ''' AS COLUMN_NAME, object_construct(*) FROM ', 
        table_name, ' QUALIFY ROW_NUMBER() OVER (PARTITION BY ',
        
        {% for column in results_list_exe %}
            column
            {% if not loop.last %}, {% endif %}
        {% endfor %},

        ' ORDER BY 1) = 2' 
    ), 
    ' UNION\t\n'
)
FROM information_schema.columns
WHERE table_name IN (
    SELECT table_name 
    FROM INFORMATION_SCHEMA.tables 
    WHERE table_type = 'BASE TABLE' 
    AND table_schema = 'CUSTOMER'
)
{% endset %}

{% set res = check_null_values(query_3) %}

SELECT
    *
FROM (VALUES 
    {% for row in res %}
        ('{{ row[0] }}','{{row[1]}}','{{row[2]}}') {% if not loop.last %},{% endif %}
    {% endfor %}
) AS results_list (table_name,column_name,error_data)

{% if not results_list_exe %}
    UNION ALL
    SELECT NULL AS table_name, NULL AS column_name, NULL AS error_data
    WHERE 1=0
{% endif %}
