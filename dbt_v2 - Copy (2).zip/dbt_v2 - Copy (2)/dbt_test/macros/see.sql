{% macro see() %}
    {% set queryf %}
        SELECT table_name 
        FROM information_schema.tables
        WHERE table_type = 'BASE TABLE' 
        AND table_schema = 'CUSTOMER';
    {% endset %}

    {% set resultf = run_query(queryf) %}

    {% set all_results = [] %}

    {% if execute %}
        {% for sing_table in resultf.rows %}
            {% set query %}
                SHOW PRIMARY KEYS IN {{ sing_table[0] }};
            {% endset %}

            {% set result = run_query(query) %}

            {% if execute %}
                {% set query_2 %}
                    SELECT "column_name" 
                    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
                {% endset %}

                {% set result_2 = run_query(query_2) %}

                {% if execute and result_2.rows %}
                    {% set query_3 %}
                        SELECT
                            '{{ sing_table[0] }}' AS table_name,
                            {% for column in result_2.rows %}
                                '{{ column[0] }} = ' || {{ column[0] }} 
                                {% if not loop.last %}, {% endif %}
                            {% endfor %} AS column_names,
                            OBJECT_CONSTRUCT(*) AS row_data
                        FROM {{ sing_table[0] }}
                        QUALIFY ROW_NUMBER() OVER (
                            PARTITION BY 
                            {% for column in result_2.rows %}
                                {{ column[0] }}
                                {% if not loop.last %}, {% endif %}
                            {% endfor %}
                            ORDER BY 1
                        ) > 1
                    {% endset %}

                    {% set results_exe = run_query(query_3) %}

                    {% if execute %}
                        {{ log("Running some_macro: " ~ results_exe.rows ~ ", " ~ results_exe.rows) }}
                        {% do all_results.extend(results_exe.rows) %}
                    {% endif %}
                {% endif %}
            {% endif %}
        {% endfor %}
    {% endif %}

    {{ return(all_results) }}
{% endmacro %}