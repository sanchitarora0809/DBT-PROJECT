{{ config(
    materialized='table'  
) }}

{% set payment_methods_query %}
    SELECT 
        LISTAGG(CONCAT('SELECT ''', table_name, ''' AS TABLE_NAME, ''', column_name, ''' AS COLUMN_NAME, object_construct(*)' ,'  FROM ', table_name, ' WHERE ', column_name, ' IS NULL'), ' UNION\t\n') 
    FROM information_schema.columns
    WHERE table_name IN 
        (SELECT table_name 
         FROM INFORMATION_SCHEMA.tables 
         WHERE table_type = 'BASE TABLE' 
         AND table_schema = 'CUSTOMER')
{% endset %}

{% set results = run_query(payment_methods_query) %}

{% if execute %}
    {% set results_list = results.rows %}

    {% set results_exe = run_query(results_list[0][0]) %}

    {% if execute %}
        {% set results_list_exe = results_exe.rows %}
    {% else %}
        {% set results_list = [] %}
    {% endif %}
{% else %}
    {% set results_list = [] %}
{% endif %}


SELECT
    *
FROM (VALUES 
    {% for row in results_list_exe %}
        ('{{ row[0] }}','{{row[1]}}','{{row[2]}}') {% if not loop.last %},{% endif %}
    {% endfor %}
) AS results_list (table_name,column_name,error_data)