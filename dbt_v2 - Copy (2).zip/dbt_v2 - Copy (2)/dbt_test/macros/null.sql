{% macro check_null_values(payment_methods_query) %}

    {% set results = run_query(payment_methods_query) %}

    {% if execute %}
        {% set results_list = results.rows %}

        {% set results_exe = run_query(results_list[0][0]) %}

        {% if execute %}
            {% set results_list_exe = results_exe.rows %}
        {% else %}
            {% set results_list_exe = [] %}
        {% endif %}
    {% else %}
        {% set results_list_exe = [] %}
    {% endif %}

    {{ return(results_list_exe) }}
{% endmacro %}