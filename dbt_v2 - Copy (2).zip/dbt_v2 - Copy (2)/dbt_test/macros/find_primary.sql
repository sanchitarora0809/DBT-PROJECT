{% macro find_primary(table_name) %}
    {% set query = 'SHOW PRIMARY KEYS IN ' ~ table_name %}
    {% set result = run_query(query) %}

    {% set query_2 = 'SELECT * FROM TABLE(result_scan(last_query_id()));' %}
    {{ log(query_2) }}
    {% set result_2 = run_query(query_2) %}

    {% if execute %}
        {% set results_list_exe = result_2.rows %}
    {% else %}
        {% set results_list_exe = [] %}
    {% endif %}
    {{ log(results_list_exe) }}
    {{ return(results_list_exe) }}
{% endmacro %}
