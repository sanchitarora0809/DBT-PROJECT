{% macro NOT_NULL() %}
{% set schema = 'CUSTOMER' %}

create or replace procedure getQueryForNotNull()
    returns varchar
    language sql
as
$$
SELECT
LISTAGG(CONCAT('SELECT ''', table_name, ''' AS TABLE_NAME, ''', column_name, ''' AS COLUMN_NAME, object_construct(*)' ,'  FROM ', table_name, ' WHERE ', column_name, ' IS NULL'), ' UNION\t\n') 
INTO :sql_query
FROM information_schema.columns 
WHERE table_name IN 
    (SELECT table_name 
     FROM INFORMATION_SCHEMA.tables 
     WHERE table_type = 'BASE TABLE' 
     AND table_schema = '{{ schema }}');

    SELECT CONCAT('BEGIN ',:sql_query,' END;') INTO :execute_query;

    EXECUTE IMMEDIATE (:execute_query);
$$;
{% endmacro %}