{% macro create_table_if_not_exists() %}

    {% set get_table_query %}  
        SELECT table_name FROM information_schema.tables 
        WHERE table_schema = 'CUSTOMER' AND table_type = 'BASE TABLE'
    {% endset %}

    {% set res = run_query(get_table_query) %}  
    {% if res and res|length > 0 %}
        {% for row in res %}
            {% set table_name = row[0] %}

            {% set check_table_exists_query %}
                SELECT table_name FROM information_schema.tables 
                WHERE table_schema = 'CUSTOMER' 
                AND table_name = '{{ table_name }}_MODIFIED'
            {% endset %}

            {% set table_exists = run_query(check_table_exists_query) %}

            {% if table_exists|length == 0 %}
                {% set get_columns_query %}
                    SELECT column_name, data_type 
                    FROM information_schema.columns 
                    WHERE table_schema = 'CUSTOMER' 
                    AND table_name = '{{ table_name }}'
                {% endset %}

                {% set columns_result = run_query(get_columns_query) %}
                {% set column_definitions = [] %}

                {% for column in columns_result %}
                    {% set column_definitions = column_definitions.append(column[0] ~ ' ' ~ column[1]) %}
                {% endfor %}

                {% do log("-------------------------------------" ~ column_definitions, info=True) %}
                
                {% do log("Created new table: " ~ table_name ~ '_MODIFIED', info=True) %}
            {% endif %}

        {% endfor %}
    {% endif %}

{% endmacro %}
