{% macro capital_case() %}

    {% set query %}
        SELECT table_name, column_name FROM {{ ref('capitalization') }}
    {% endset %}
    
    {% do log("Fetching table and column names from capitalization model...", info=True) %}
    
    {% set res = run_query(query) %}

    {% if res and res|length > 0 %}
        {% for row in res %}
        
            {% set table_name = row[0] %}
            {% set column_name = row[1] %}
            
            {% do log("Updating table: " ~ table_name, info=True) %}
            
            {% set update_query %}
                UPDATE {{ table_name }} 
                SET {{ column_name }} = INITCAP({{ column_name }}), 
                    FLAG = 1, 
                    COMMENT_TEXT = COALESCE(COMMENT_TEXT || ' | updated by autonomous system ' || {{ column_name }}, 
                        'updated by autonomous system ' || {{ column_name }})
                WHERE {{ column_name }} <> INITCAP({{ column_name }})
                AND {{ column_name }} IS NOT NULL;
            {% endset %}
            
            {% set res_2 = run_query(update_query) %}
            {% do log("Updated table: " ~ table_name, info=True) %}

        {% endfor %}
    {% else %}
        {% do log("No tables found for capitalization update.", info=True) %}
    {% endif %}

{% endmacro %}













{% macro update_null(value_to_be_replaced) %}

    {% set query %}
        SELECT table_name, column_name FROM {{ ref('null_check') }}
    {% endset %}
    
    {% do log("Fetching table and column names from capitalization model...", info=True) %}
    
    {% set res = run_query(query) %}

    {% if res and res|length > 0 %}
        {% for row in res %}
        
            {% set table_name = row[0] %}
            {% set column_name = row[1] %}
            
            {% do log("Updating table: " ~ table_name, info=True) %}
            
            {% set update_query %}
                UPDATE {{ table_name }} 
                SET {{ column_name }} = {{value_to_be_replaced}}, 
                    FLAG = COALESCE(FLAG || '| 2', '2'), 
                    COMMENT_TEXT = COALESCE(COMMENT_TEXT || ' | updated by autonomous system ' || {{ column_name }}, 
                        'updated by autonomous system ' || {{ column_name }})
                WHERE {{ column_name }} IS NULL;
            {% endset %}
            
            {% set res_2 = run_query(update_query) %}
            {% do log("Updated table: " ~ table_name, info=True) %}

        {% endfor %}
    {% else %}
        {% do log("No tables found for capitalization update.", info=True) %}
    {% endif %}

{% endmacro %}



{% macro format_table() %}

    {% set query %}
        SELECT table_name, column_name FROM {{ ref('formatting') }}
    {% endset %}
    
    {% do log("Fetching table and column names from formatting model...", info=True) %}
    
    {% set res = run_query(query) %}

    {% if res and res|length > 0 %}
        {% for row in res %}
        
            {% set table_name = row[0] %}
            {% set column_name = row[1] %}
            
            {% do log("Updating table: " ~ table_name, info=True) %}
            
            {% set update_query %}
                UPDATE {{ table_name }} 
                SET {{ column_name }} = TRIM({{ column_name }}), 
                    FLAG = COALESCE(FLAG || '| 3', '3'), 
                    COMMENT_TEXT = COALESCE(COMMENT_TEXT || ' | updated by autonomous system ' || {{ column_name }}, 
                        'updated by autonomo
                         us system ' || {{ column_name }})
                WHERE {{ column_name }} <> TRIM({{ column_name }});
            {% endset %}
            
            {% set res_2 = run_query(update_query) %}
            {% do log("Updated table: " ~ table_name, info=True) %}

        {% endfor %}
    {% else %}
        {% do log("No tables found for capitalization update.", info=True) %}
    {% endif %}

{% endmacro %}





{% macro fix_outliers() %}

    {% set query %}
        SELECT table_name, column_name FROM {{ ref('outliers') }}
    {% endset %}
    
    {% do log("Fetching table and column names from formatting model...", info=True) %}
    
    {% set res = run_query(query) %}

    {% if res and res|length > 0 %}
        {% for row in res %}
        
            {% set table_name = row[0] %}
            {% set column_name = row[1] %}
            
            {% do log("Updating table: " ~ table_name, info=True) %}
            
            {% set update_query %}
                UPDATE {{ table_name }} 
                SET {{ column_name }} = (SELECT AVG({{ column_name }}) FROM {{ table_name }}), 
                    FLAG = COALESCE(FLAG || '| 4', '4'), 
                    COMMENT_TEXT = COALESCE(COMMENT_TEXT || ' | updated by autonomous system ' || {{ column_name }}, 
                        'updated by autonomo
                         us system ' || {{ column_name }})
                WHERE ABS(({{ column_name }} - (SELECT AVG({{ column_name }}) FROM {{ table_name }})) / (SELECT STDDEV({{ column_name }}) FROM {{ table_name }})) > 3 ;
            {% endset %}
            
            {% set res_2 = run_query(update_query) %}
            {% do log("Updated table: " ~ table_name, info=True) %}

        {% endfor %}
    {% else %}
        {% do log("No tables found for capitalization update.", info=True) %}
    {% endif %}

{% endmacro %}