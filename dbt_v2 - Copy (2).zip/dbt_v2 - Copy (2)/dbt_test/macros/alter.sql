{% macro alter_table() %}

    {% set get_table_query %}  
        SELECT table_name FROM information_schema.tables 
        WHERE table_schema = 'CUSTOMER' AND table_type = 'BASE TABLE'
    {% endset %}

    {% set res = run_query(get_table_query) %}  
    {% if res and res|length > 0 %}
        {% for row in res %}
            {% set table_name = row[0] %}

            {% set check_flag_column_query %}
                SELECT column_name FROM information_schema.columns 
                WHERE table_schema = 'CUSTOMER' 
                AND table_name = '{{ table_name }}' 
                AND column_name = 'FLAG'
            {% endset %}

            {% set check_comment_column_query %}
                SELECT column_name FROM information_schema.columns 
                WHERE table_schema = 'CUSTOMER' 
                AND table_name = '{{ table_name }}' 
                AND column_name = 'COMMENT_TEXT'
            {% endset %}

            {% set flag_exists = run_query(check_flag_column_query) %}
            {% set comment_exists = run_query(check_comment_column_query) %}

            {% if (flag_exists|length == 0) or (comment_exists|length == 0) %}
                {% set alter_query %}
                    {% if flag_exists|length == 0 %}
                        ALTER TABLE {{ table_name }}
                        ADD COLUMN FLAG STRING , COMMENT_TEXT STRING
                    {% endif %};
                {% endset %}

                {% set res_2 = run_query(alter_query) %} 

                {% do log("Altering table: " ~ table_name, info=True) %}
            {% else %}

            {% endif %}

        {% endfor %}
    {% endif %}

{% endmacro %}
