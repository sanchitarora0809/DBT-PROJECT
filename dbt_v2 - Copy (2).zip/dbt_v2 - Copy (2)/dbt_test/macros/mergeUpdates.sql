{% macro dynamic_full_outer_join(table_1, table_2) %}

{% set query_1 %}
 WITH column_info AS (
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_NAME = UPPER('{{ table_name }}')
    )
    SELECT LISTAGG(COLUMN_NAME, ', ') AS column_list FROM column_info;
{% endset %}

{% set res_1 = run_query(query_2) %}


{% set query %}
    WITH column_info AS (
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = UPPER('{{ table_1 }}')
        UNION
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = UPPER('{{ table_2 }}')
    ),
    final_query AS (
        SELECT 
            {% for column in res_1 %}
                COALESCE({{ table_1 }}.{{ column }}, {{ table_2 }}.{{ column }}) AS {{ column }}{% if not loop.last %}, {% endif %}
            {% endfor %},
    
            CASE 
                WHEN {{ table_1 }}.id IS NOT NULL AND {{ table_2 }}.id IS NOT NULL THEN 1  
                ELSE 0 
            END AS flag
    
        FROM {{ table_1 }}
        FULL OUTER JOIN {{ table_2 }}
        ON 
        ({{ table_1 }}.full_name = {{ table_2 }}.full_name AND {{ table_1 }}.address = {{ table_2 }}.address)
    )
    select * from final_query
{% endset %}

{% set result = run_query(query) %}
 
{{ return(result) }}
 
{% endmacro %}